#include <ros/ros.h>
#include <can_msgs/Frame.h>
#include <std_msgs/Float32.h>
#include "mower_msgs/VehicleCmd.h"
#include "stdint.h"

// ȫ�ֱ���
ros::Publisher g_can_pub;
ros::Subscriber vehicle_cmd_sub;


// ��������ص�����
void vehicle_cmd_callback(const mower_msgs::VehicleCmd::ConstPtr &msg) {

    std::cout<<"dhaoidhsaisdsoda"<<std::endl;
    int linear_vel = static_cast<int>(msg->drive_value);
    int angular_vel = static_cast<int>(msg->turn_value);
    std::cout<<"dhaoidhsaioda"<<std::endl;
    can_msgs::Frame can_msg;
    
    // ����CAN֡ͷ
    can_msg.header.stamp = ros::Time::now();
    can_msg.id = 0x00000005;
    can_msg.dlc = 8;
    can_msg.is_extended = true;
    can_msg.is_rtr = false;
    can_msg.is_error = false;
    
    
    // �����ٶȣ�ǰ4�ֽڣ�
    int32_t linear_vel_int = static_cast<int32_t>(linear_vel);
    can_msg.data[0] = (linear_vel >> 24) & 0xFF;
    can_msg.data[1] = (linear_vel >> 16) & 0xFF;
    can_msg.data[2] = (linear_vel >> 8) & 0xFF;
    can_msg.data[3] = linear_vel & 0xFF;

    // ���ٶȣ���4�ֽڣ�
    int32_t angular_vel_int = static_cast<int32_t>(angular_vel);
    can_msg.data[4] = (angular_vel >> 24) & 0xFF;
    can_msg.data[5] = (angular_vel >> 16) & 0xFF;
    can_msg.data[6] = (angular_vel >> 8) & 0xFF;
    can_msg.data[7] = angular_vel & 0xFF;

    // ����CAN֡
    //sendCanFrame(can_id, data);
    g_can_pub.publish(can_msg);
    
    ROS_INFO("Sent velocity command: linear=0x%08X angular=0x%08X", 
             (unsigned int)linear_vel_int, (unsigned int)angular_vel_int);
}

int main(int argc, char** argv) {
    // ��ʼ��ROS�ڵ�
    ros::init(argc, argv, "agv_can_bridge");
    ros::NodeHandle nh;
    // ros::NodeHandle private_nh("~");
    
    // �Ӳ�����������ȡ����
    // std::string can_topic;
    // int bitrate;
    
    // private_nh.param<std::string>("can_topic", can_topic, "sent_messages");
    // private_nh.param<int>("bitrate", bitrate, 500000);
    
    // ����CAN��Ϣ������
    g_can_pub = nh.advertise<can_msgs::Frame>("/sent_messages", 10);
    
    // �����������
    std::cout<<"202513222"<<std::endl;
    // ��ѭ��
    ros::Rate loop_rate(50); // 50Hz
    while(ros::ok()) {
        ros::spinOnce();
        ros::Subscriber vehicle_cmd_sub = nh.subscribe("/vehicle/cmd", 2, vehicle_cmd_callback);

        loop_rate.sleep();
    }
    
    return 0;
}