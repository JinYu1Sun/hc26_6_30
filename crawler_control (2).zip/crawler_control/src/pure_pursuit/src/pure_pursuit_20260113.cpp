#include "geometry.h"
#include <cstdlib>
#include <pure_pursuit/pure_pursuit.h>
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <std_msgs/UInt8.h>
#include <vector>
#include <yaml-cpp/yaml.h>

#define VERSION "1.0"
#define SPEED_TARGET_POINT 0
static int ctv = 0;//1500
ControlCommand command; // ?��ֱ���������setControl_main()��command_publish()
ControlError ctlE = {44.4f, 44.4f, 44.4f}; // add Error feedback, data_init

int ld_i = 4;       // 2
bool turn_flag = 0; // ��ʽת���־�?
bool gear_flag =
    0; // ��λ��?��ת��㣬��һ�ε���?1����ζ��ת�������??���滮���루50cm��
bool turn_state = 0;                // ת�����??->��һ��ת���״̬�?
bool tem_flag = 0;                  // ʱ��Լ����־
bool initial_approach_mode = false; // cnk 0514 ��ʼ�ӽ�ģʽ
int approach_count = 0;             // cnk 0514 ��ʼ�ӽ�ģʽ������
bool first_set = false;
bool adjust_error = false;
int count = 0;
double last_distance = std::numeric_limits<double>::max();

void ResetFlag() {
  ld_i = 4;      // 2
  turn_flag = 0; // ��ʽת���־�?
  gear_flag =
      0; // ��λ��?��ת��㣬��һ�ε���?1����ζ��ת�������??���滮���루50cm��
  turn_state = 0; // ת�����??->��һ��ת���״̬�?
  tem_flag = 0;   // ʱ��Լ����־
}

// Constructor
PurePursuit::PurePursuit()
    : private_nh_("~"), LOOP_RATE_(20), // 50
      is_planning_result_set_(false), is_carposition_set_(false),
      is_velocity_set_(false), desire_speed_com(0.0) /*,
                                desire_turn_angle(0.0)*/
{
  initForROS();
}

// DestructorFAR
PurePursuit::~PurePursuit() {}

void PurePursuit::setPath_main(void) {
  int i = 0;
  waypose p1; // �Ķ�

  float theta = car_position.yaw - M_PI_2;
  memset(local_waypoints, 0, sizeof(local_waypoints));
  float cosval = cosf(theta);
  float sinval = sinf(theta);

  for (i = 0; i < planning_result.point_num; i++) {
    p1.point.x = planning_result.x[i] - car_position.position_x;
    p1.point.y = planning_result.y[i] - car_position.position_y;
    p1.heading = robot::geometry::NormalizeAngle(
        planning_result.heading[i] - car_position.yaw); // �ֲ���λ�����??
    local_waypoints[i].point.x = p1.point.x * cosval + p1.point.y * sinval;
    local_waypoints[i].point.y = p1.point.x * (-sinval) + p1.point.y * cosval;
    local_waypoints[i].heading = p1.heading;
    // if(i<=9){
    ROS_INFO("D1#localpath# x:%.3f,y:%.3f,heading:%.3f",
    local_waypoints[i].point.x,local_waypoints[i].point.y,local_waypoints[i].heading);
    // //debug_1
    // }
  }
}

void PurePursuit::updatestatus(void) {
  path_state = updatePathState();
  lat_track_state = updateLatTrackState();

  static int tnum = 0;
  tnum++;
  if (tnum > 3 * LOOP_RATE_) {
    // ROS_INFO("path_state: %d,track_state: %d", path_state, lat_track_state);
    tnum = 0;
  }
}

int PurePursuit::updatePathState(void) {
  float distance;
  if (planning_result.point_num == 0 ||
      planning_result.point_num < look_ahead_index)
    return PATH_FINISHED;

  if (!getNearestIndex(&nearest_waypoint_id)) {
    return PATH_INVALID;
  }
  if (getLatDistance(&distance)) {
    if (fabsf(distance) > kMaxPathDistance) {
      ROS_INFO("PATH_TOO_FAR ~dis~AAAAAAAAAA  %.3f", distance); //
      return PATH_TOO_FAR;
    } else {
      stop_path_flag = 0;
      return PATH_OK;
    }
  }
  ROS_INFO("D2#unmatched PathState , acquiesce PATH_INVALID"); //@ debug_2
  return PATH_INVALID;
}

int PurePursuit::updateLatTrackState(void) {
  if (!getLatDistance(&lat_error)) {
    if (lat_error < kMaxLatError)
      lat_track_state = CONTROL_OK;
    else
      lat_track_state = CONTROL_INIT;
  }
  switch (lat_track_state) {
  case CONTROL_INIT:
    return CONTROL_INIT;
    break;
  case CONTROL_OK:
  case CONTROL_OUT_OF_BOUND:
    if (lat_error < kStoppingLatError)
      return CONTROL_OK;
    else {
      ROS_INFO("CONTROL_OUT_OF_BOUND ~dis~  %.3f", lat_error); //
      return CONTROL_OUT_OF_BOUND;
    }
    break;
  case CONTROL_FINISHED:
    return CONTROL_FINISHED;
    break;
  default:
    return CONTROL_INIT;
  }
}

int PurePursuit::getNearestIndex(int *index) {
  int nearest_index = -1;
  int i, near_i = -1;
  float up_dis = 999.0;
  *index = -1;
  if (planning_result.point_num < 1) {
    return 0;
  }

  for (i = 0; i < planning_result.point_num; i++) {
    // in 1224 �� ����������߼�?? Ҫ�ж� �Ƿ񶪵�

    // cm >=0
    float dis = robot::geometry::hypotFast(local_waypoints[i].point.x * 100,
                                           local_waypoints[i].point.y * 100);
    if (dis < up_dis) {
      up_dis = dis;
      near_i = i;
    }
    if (dis > 300) {
      // break;
      continue;
    }
    /*if (local_waypoints[i].point.y <= 0.0f) // �ֲ�ת����?���y��ֵ����ĵ�??
    @add continue; nearest_index = i; break;*/
  }
  nearest_dis = up_dis;
  nearest_index = near_i;
  if (!nearest_index) {
    int j = 0;
    for (j; j < nearest_index; j++) {
      if (planning_result.gear[j] != planning_result.gear[nearest_index]) {
        nearest_index = j;
      }
    }
    nearest_index = nearest_index != near_i ? 0 : near_i;
    // ROS_INFO("D33#nearest _index:%d,near_i:%d,x:%.3f,y:%.3f",
    // nearest_index,near_i,
    //    local_waypoints[near_i].point.x,local_waypoints[near_i].point.y);
  }
  // ROS_INFO("D3#nearest _index:%d,dis:%.3f,x:%.3f,y:%.3f",
  // nearest_index,nearest_dis,
  //    local_waypoints[nearest_index].point.x,local_waypoints[nearest_index].point.y);
  //    //debug_3
  if (nearest_index == -1) // not found
  {
    ROS_ERROR_THROTTLE(1, "ERROR ~not found nearest_waypoint~ : %d ",
                       nearest_index);
    return 0;
  }
  if (nearest_dis > kMaxPathDistance) {
    ROS_INFO("PATH_TOO_FAR ~dis~BBBBB  %.3f", nearest_dis); //
    return PATH_TOO_FAR;
  }
  *index = nearest_index;
  return 1;
}

int PurePursuit::getLatDistance(
    float *distance) { //:1224 debug == 0�ͺ�����й�??
  *distance = 999.99f;
  if (nearest_waypoint_id > planning_result.point_num)
    return 0;

  if (nearest_waypoint_id ==
      0 /*&& local_waypoints[nearest_waypoint_id].point.y < 0.20*/) {
    *distance = local_waypoints[nearest_waypoint_id].point.x;
  }
  if (nearest_waypoint_id >= 1) {
    *distance = getDistanceToLine(&local_waypoints[nearest_waypoint_id - 1],
                                  &local_waypoints[nearest_waypoint_id]);
  }
  // ROS_INFO("nearest_waypoint_id : %d",nearest_waypoint_id);
  ctlE.e_pos = *distance;
  return 1;
}
// ���㳵����?�λ�ã����������? (0,0)����ԭ�㣩�������� ?p1 �� ?p2
// �����ֱ�ߵĴ�ֱ����??
float PurePursuit::getDistanceToLine(waypose *p1,
                                     waypose *p2) { // �복�����??��0�������??
  float A = p1->point.y - p2->point.y;
  float B = p2->point.x - p1->point.x;
  float C = p1->point.x * p2->point.y - p1->point.y * p2->point.x;

  if (fabsf(A * A + B * B) < 0.01f)
    return sqrtf(powf(p1->point.x, 2.0f) + powf(p1->point.y, 2.0f));
  return (-C / sqrtf(A * A + B * B));
}

int PurePursuit::findGoalPoint(void) {
  if (planning_result.point_num < 1) // :2504 <=��Ϊ <
    return 0;
  if (planning_result.point_num > look_ahead_index) {
    goal = &local_waypoints[look_ahead_index];
    goal_id = look_ahead_index;
    // return 1;
  } else {
    goal = &local_waypoints[planning_result.point_num - 1];
    path_state = PATH_FINISHED;
    goal_id = planning_result.point_num - 1;
  }
  // ROS_INFO("D0goal->y:%.3f,x:%.3f,heading:%.3f,ld_index:%d", goal->point.y,
  // goal->point.x,goal->heading,goal_id); //debug_0
  return 1;
}

int PurePursuit::isGoalValid(void) {
  // Ԥ�鷶Χ�ڱ�֤ ����?���?
  int i;
  float lat_error_temp; // cm
  if (nearest_waypoint_id < 0 || look_ahead_index < 0 ||
      planning_result.point_num < look_ahead_index)
    return 0;

  max_goal_lat_error = 0.0f;

  for (i = nearest_waypoint_id; i < look_ahead_index; i++) {
    if (isinf(desire_ICR))
      lat_error_temp = fabsf(local_waypoints[i].point.x) * 100;
    else
      lat_error_temp = fabsf(
          sqrtf(powf(local_waypoints[i].point.x * 100 - desire_ICR, 2.0f) +
                powf(local_waypoints[i].point.y * 100, 2.0f)) -
          fabsf(desire_ICR)); // �ֲ�·��Բ�����߰뾶Բ����ֵ

    if (lat_error_temp > max_goal_lat_error)
      max_goal_lat_error = lat_error_temp;

    // ROS_INFO("D6#lat_error_temp %.3f,ICR %.3f", lat_error_temp,desire_ICR);
    // //debug_6
    if (lat_error_temp > kMaxLatError) {
      return 0;
    }
  }
  return 1;
}

void PurePursuit::setControl_main(void) {
  int gear_count = 0;
  desire_speed_com = planning_result.speed[SPEED_TARGET_POINT] * 100.0f;
  int ld_init;
  // if(initial_approach_mode)
  // {     // cnk 0514 ��ʼ�ӽ�ģʽ
  // ld_init=4;
  // }
  // else{
  ld_init = desire_speed_com < 35 ? ld_i + 4 : ld_i + 10;   //}
  if (nearest_waypoint_id != -1 && !need_turn_for_new_path) // cnk 0511
  {
    bool found = false; // ����?���ҵ��˺���Ԥ���?
    look_ahead_index = planning_result.point_num - 1;
    // nearest_waypoint_id+1
    for (int i = 0; i < planning_result.point_num; i++) {
      // �Ż�ת���߼���add�� y < 0.20 ; nearest_dis < 0.2
      if (turn_state) {
        gear_flag = 0;
        turn_state = planning_result.gear[SPEED_TARGET_POINT + 1] == 2
                         ? 0
                         : turn_state; // ��?�Ԥ��ת��?
      } else {
        gear_flag = planning_result.gear[SPEED_TARGET_POINT] == 2 ? 1 : 0; //@
      }
      // turn_state = planning_result.point_num == 1 ? 0 : turn_state; //@
      // ���һ����??����·�����Ͻ�2
      // 0109 add stop_tem_flag ��תҪ��
      if (turn_flag || (gear_flag && local_waypoints[0].point.y <
                                         0.09)) { // TODO 0.09�Ƿ����??cnk
        static ros::Time t1;                      // ����Ϊ��̬����������ʱ��ֵ
        static float init_y = 0, last_y = 0;      // ��һ��λ��?��ۼ��?
        tem_flag = 1;
        if (turn_flag) {
          break;
        }
        if (!stop_tem_flag && tem_flag) {
          t1 = ros::Time::now();
          init_y = local_waypoints[0].point.y;
          tem_flag = 0;
        }
        stop_tem_flag = 1; //
        //
        // ROS_INFO("<-------- Turn: stop---------->");

        last_y = local_waypoints[0].point.y;
        auto t2 = ros::Time::now();
        auto det = getDelay(t2, t1); // 4֡��ʱ���??
        auto add_y = fabs(last_y - init_y);
        // ROS_INFO("Ds4#det %.3f,t2 %.3f,t1 %.3f", det,t2.toSec(),t1.toSec());
        // //debug_s ROS_INFO("Dsdelat_Vy =  %.3f", add_y*100 / det);
        // //������֡�ٶ��ж� cm/s
        if (det >= 0.2) {
          bool addv_flag = add_y * 100 / det < 20 ? 1 : 0; // TODO cnk  20+5
          // ROS_WARN("speed:  %.4f", add_y);
          if (addv_flag) {
            turn_flag = 1;
            first_set = false;
            adjust_error = false;
            stop_tem_flag = 0;
            add_y = 0;
            break; // ����forѭ��
          } else {
            t1 = ros::Time::now();
            init_y = local_waypoints[0].point.y;
            stop_tem_flag = 1; // �ٶȹ���ͣ��      //
            // ROS_INFO("<-------- Speed: stop---------->");
            add_y = 0;
            break;
          }
        } else {
          stop_tem_flag = 1; // det<0.2 ͣ��      //
          // ROS_INFO("<-------- distance: stop---------->");
          break; // ����forѭ��
        }
      }
      if (planning_result.gear[i] == 2) {
        gear_count++; // �������� 1
        if (turn_flag == 0 && gear_count == 1) {
          // �ҵ���һ�� gear[i] == 2
          look_ahead_index = i;
          break; // ����ѭ��
        } else if (turn_flag == 1 && gear_count == 2) {
          // �ҵ��ڶ��� gear[i] == 2
          look_ahead_index = i;
          break; // ����ѭ��
        }
      }
      //    turn_flag = 0;
    }
    ////////////// cnk 0514
    static ros::Time first_stop_time = ros::Time::now();
    if (stop_tem_flag == 1) {
      // ����?�񳬹�?��?��ʱʱ��?
      double total_stop_time = (ros::Time::now() - first_stop_time).toSec();

      if (total_stop_time > 0.5) { // ?���?0.5������
        stop_tem_flag = 0;
        turn_flag = true;
        first_set = false;
        adjust_error = false;
        first_stop_time = ros::Time::now(); // ����ʱ���??
      }
    } else {
      first_stop_time = ros::Time::now();
    }
    ////////////// cnk 0514
    look_ahead_index = look_ahead_index <= ld_init
                           ? look_ahead_index
                           : ld_init; // 0107 ����?�����Զ��?
    // ROS_INFO("D44#ld_index %d,gear_flag %d,stop_tem %d,turn_flag %d,t_state
    // %d", look_ahead_index, gear_flag, stop_tem_flag, turn_flag, turn_state);
    // // debug_44
  }
  // ROS_INFO("D44#desire_speed_com %f,gear_flag %d,stop_tem %d,turn_flag
  // %d,t_state %d", desire_speed_com, gear_flag, stop_tem_flag, turn_flag,
  // turn_state);
  vir_wheel_track = 1.0 * wheel_track; // �궨  �뻬��Ħ���й�
  // pl0_heading = planning_result.heading[0];
  ctlE.e_theta = (local_waypoints[0].heading - 0) * 180 /
                 M_PI; // ����������0�Ĳ�ֵ ��λ����
  // ROS_INFO("D4#point_num %d,V_des %.3f cm/s,ld_init: %d",
  // planning_result.point_num,desire_speed_com,ld_init);  //debug_4

  while (!stop_tem_flag) // 1
  {
    if (need_turn_for_new_path)
      break;

    // ����
    static float diff_v = 0;
    // �ؼ� turn_flag = 1 ʱ dv = 1500
    // command.drive_value =
    // calculateDriveValue(desire_speed_com,planning_result.speed[look_ahead_index-1],turn_flag,
    // avoid_state_data); look_ahead_index-1 �ᱨ�δ���
    command.drive_value = calculateDriveValue(
        desire_speed_com, planning_result.speed[look_ahead_index], turn_flag,
        avoid_state_data);
    ctv = desire_speed_com < 30 ? 0 : 0; // ת�����ֵ���?��ʼ��1501 : 1501
    command.turn_value = ctv;
    if (desire_speed_com <= 30.0 && planning_result.point_num > 1) {
      // ?������? delta_heading  ���� �� ��ת���� ˳ת |���� ��λ�߼�δ��
      float delta_heading = -local_waypoints[0].heading; //@
      // ROS_INFO("D05#near_wp_id %d,delta_heading %.4f,l[0] %.3f,near %.3f",
      // nearest_waypoint_id,delta_heading,
      //          local_waypoints[0].heading,local_waypoints[nearest_waypoint_id].heading);
      //          //debug_05
      // ����ת��

      // ROS_INFO("start turn--------------------"); //debug_5
      if (turn_flag) {
        double dx = planning_result.x[0] - car_position.position_x;
        double dy = planning_result.y[0] - car_position.position_y;
        double distance_to_start = hypot(dx, dy);
        double desired_heading = atan2(dy, dx);
        double heading_error =
            robot::geometry::NormalizeAngle(desired_heading - car_position.yaw);
            ROS_INFO("heading_error=%lf",heading_error);
        if (distance_to_start > 0.05 && !adjust_error) {
          if (fabsf(heading_error) > 0.06 && !first_set) {
            command.drive_value = 0;//1500
            command.turn_value = (heading_error > 0) ? -50 : 50;//1270 : 1730
            count = 0;
            ROS_INFO("Adjusting heading to target point...");
          } else {
            first_set = true;
            if (distance_to_start > last_distance) {
              count++;
            } else {
              count = 0; // �б�С������
            }

            if (count >= 3) {
              adjust_error = true;
              count = 0;
            }
            command.drive_value =15;//1600
            command.turn_value = 0;//1500
            last_distance = distance_to_start;
          }
        } else {
          // �������??
          adjust_error = true;
          count = 0;
          ROS_INFO("adjust completed.");
        }

        ROS_WARN("start turn, %.4f,%.4f", planning_result.x[0],
                 planning_result.y[0]);                // 0.1����=5.73��
        if (fabsf(local_waypoints[0].heading) <= 0.06) // 0.096
        {
          geometry_msgs::Point point_msg;
          point_msg.z = 999;
          if (avoid_state_data == 1)
            ROS_WARN("********************************");
          path_too_far_pub_.publish(point_msg);
          ROS_WARN("gear =2 should droped,turn finish, %.4f,%.4f",
                   planning_result.x[0], planning_result.y[0]);
          turn_state = 1;
          turn_flag = 0;
          // command.drive_value = 1730; // 1750
          break; // ����whileѭ��
        }
        if (delta_heading < 0) {
          command.turn_value = -48;//1270
          command.drive_value = 0;//1500
          break;
        } else {
          command.turn_value = 48;//1730
          command.drive_value = 0;//1500
          break;
        }
      }
    }

    if (!turn_flag) {
      if (findGoalPoint()) // �ҵ�Ԥ���??
      {
        if (fabsf(goal->heading) <= 0.02 &&
            fabsf(ctlE.e_pos) < 0.06) // �ٶ�Ԥ�������ǰ��??
        {
          // ��Ҫ�ٶȷ�������ֵPID
          command.turn_value = ctv;
          desire_ICR = INFINITY;
        } else // Ԥ��㲻����ǰ��??
        {
          desire_ICR = (pow(goal->point.x * 100, 2.0f) +
                        pow(goal->point.y * 100, 2.0f)) /
                       (2.0f * goal->point.x * 100); // ������ �� ��ת���� ��ת
          command.turn_value = calculateTurnValue(
              gear_flag, local_waypoints[0], goal, goal_id, last_turn_value);
          break;
        }
      } else // û���ҵ�Ԥ���??ͣ��
      {
        // command.turn_value = 1500;
        // command.drive_value = 1500;
        desire_ICR = INFINITY;
        path_state = PATH_FINISHED;
        ROS_INFO("with out target point");
        break;
      }

      if (isGoalValid()) // ��?�ת���ܹ���֤Ԥ�������·������?���??
      {
        // ����������ں�������ʱʹ�ý���Ԥ�����ƺ������??
        look_ahead_index = nearest_waypoint_id + ld_i; // for debug
        // ROS_INFO("nearest_waypoint_id  %d", nearest_waypoint_id);
        for (int i = 0; i < ld_i; i++) {
          if (planning_result.gear[i] != planning_result.gear[i + 1]) {
            look_ahead_index = i;
            break;
          } else {
            look_ahead_index = nearest_waypoint_id + ld_i;
          }
        }

        if (findGoalPoint()) // ���� Ԥ����goal, <= ld_i
        {
          if (fabsf(goal->heading) <= 0.02 &&
              fabsf(ctlE.e_pos) < 0.06) // �ٶ�Ԥ�������ǰ��??
          {
            command.turn_value = ctv;
            desire_ICR = INFINITY;
          } else // Ԥ��㲻����ǰ��??
          {
            float desire_ICR = (pow(goal->point.x * 100, 2.0f) +
                                pow(goal->point.y * 100, 2.0f)) /
                               (2.0f * goal->point.x * 100);
            command.turn_value = calculateTurnValue(
                gear_flag, local_waypoints[0], goal, goal_id, last_turn_value);
            break;
          }
        }
        break; // ����whileѭ��
      } else if (
          fabs(goal->point.y < 0.9f) &&
          (goal_id <
           2)) // ��?�ת���ܹ���֤Ԥ�������·������?��Ԥ������������������??
      {
        //  1230 �жϼ�fabs
        // ROS_INFO("Continue driving %d,%f,%d,%d", (goal->point.y < 3.0f),
        // goal->point.y, (goal_id < 2), goal_id);
        break;
      } else { // ��?�ת���ܹ���֤Ԥ�������·������?��Ԥ�������Լ��?
        look_ahead_index--;
        // ROS_INFO("D8#look_ahead_index -- : %d", look_ahead_index);
      }

      // if (look_ahead_index <= 0)
      if (look_ahead_index <= 0) {
        command.turn_value = 0;//1500
        command.drive_value = 0;//1500
        desire_ICR = INFINITY;
        // ROS_INFO("look_ahead_index <= 0");
        break;
      }
    }
  }
  // add speed range
  int tv = command.turn_value;
  int dv = command.drive_value;
  if (command.turn_value >= -60 && command.turn_value <= 60) {//2300
    command.turn_value = command.turn_value;
  } else {
    command.turn_value = ctv;
  }
  if (command.drive_value >= -60 && command.drive_value <= 60) {//2300
    command.drive_value = command.drive_value;
  } else {
    command.drive_value = 40; // 1900
  }
   ROS_INFO("D9#cmd# t_v:%d,d_v:%d,~~tv %d,dv %d", command.turn_value,
   command.drive_value, tv, dv);

  // �� add c_finished
  if (avoid_state_data != 1 || planning_result.pathtype == 0) {
    if (!c_finish && path_state == PATH_FINISHED &&
        fabsf(goal->point.y) < 0.2f && fabsf(vehicle_info.vehicle_speed) > 2) {
      // ROS_INFO("path_state is PATH_FINISHED and goal->point.y = %.3f",
      // goal->point.y);
      std::string filePath =
          "/home/nvidia/Mower/src/location_map/ControlStatus.txt";
      std::ofstream outFile(filePath);
      if (!outFile.is_open()) {
        ROS_WARN("can't open ControlStatus.txt");
        // std::cerr << "can't open ControlStatus.txt" << std::endl;
      }
      float c_length =
          sqrt(pow(goal->point.x, 2.0f) + pow(goal->point.y, 2.0f)) * 100; // cm
      if (c_length < 10) {
        ROS_INFO("~~ control finished , end_length : %.3f cm", c_length);
        c_finish = true;
        path_state = PATH_INIT;
        lat_track_state = CONTROL_FINISHED;
        outFile << c_finish << std::endl;
        outFile.close();
      }
    } else {
      // ROS_INFO("path_state: %d,finish: %d,goal->point.y: %.3f,track_state:
      // %d", path_state, c_finish, goal->point.y,lat_track_state);
      // //-debug: add
      c_finish = false;
    }
  }
}

void PurePursuit::act(void) {
  switch (path_state) {
  case PATH_OK:
    switch (lat_track_state) {
    case CONTROL_INIT:
    case CONTROL_OK:
      stopping_req_by_lat_control = 0;
      break;
    case CONTROL_OUT_OF_BOUND:
    case CONTROL_FINISHED:
    default:
      stopping_req_by_lat_control = 1;
      break;
    }
    break;
  case PATH_INVALID:
    stopping_req_by_lat_control = 1; //@cnk
    ROS_WARN("PATH_INVALID.");
    break;
  case PATH_TOO_FAR:
    stop_path_flag = 1; // add
    // ROS_INFO("PATH_TOO_FAR ~stop_ =  %d", stop_path_flag); //
    break;
  case PATH_INIT:
  case PATH_FINISHED:
  default:
    stopping_req_by_lat_control = 1;
    ;
    break;
  }
}
void PurePursuit::latcontrol_algorithm(void) // 20ms
{
  setPath_main();
  updatestatus();
  setControl_main();
  act();
}
// Callback
/*
void PurePursuit::callbackFromPlanningResult(const util::LocalPathConstPtr
&msg_planning_result)
{
    planning_result = *msg_planning_result;
    error_status = (planning_result.point_num > 50 || planning_result.point_num
< 1) ? 1 : 0; if (error_status)
    {
        is_planning_result_set_ = false;
        ROS_ERROR_THROTTLE(1, "~ point_num is wrong : %d ",
planning_result.point_num); return;
    }
    if (last_pathtype != planning_result.pathtype)
    {
        ROS_INFO_THROTTLE(2, "New path detected");
        need_turn_for_new_path = true;
        //  stop_tem_flag = 1;//cnk
    }
    if (need_turn_for_new_path)
    {
        // ROS_INFO("stop_tem_flag  %d", stop_tem_flag);
        double heading =
robot::geometry::NormalizeAngle(planning_result.heading[0] - car_position.yaw);
        ROS_INFO("error heading  %.3f", heading);
        if (fabsf(heading) <= 0.096)
        {
            geometry_msgs::Point point_msg;
            point_msg.z = 999;
            path_too_far_pub_.publish(point_msg);
            ROS_WARN("first gear =2 droped");
            ros::Duration(0.5).sleep();  //cnk 0514
            need_turn_for_new_path = false;
            initial_approach_mode = true; // cnk 0514 ���ó�ʼ����ģʽ
            approach_count = 0;
            ResetFlag(); //
            // command.drive_value = 1730; // 1750
        }
        if (heading > 0)
        {
            command.turn_value = 1270;
            command.drive_value = 1500;
        }
        else
        {
            command.turn_value = 1730;
            command.drive_value = 1500;
        }
    }
    last_pathtype = planning_result.pathtype;
    is_planning_result_set_ = true;
}
*/

bool already_moving_straight = false;
bool align_to_path_point = false;
double last_distance_to_start = std::numeric_limits<double>::max();
int distance_increase_count = 0;
void PurePursuit::callbackFromPlanningResult(
    const util::LocalPathConstPtr &msg_planning_result) {
  planning_result = *msg_planning_result;
  error_status = (planning_result.point_num < 1)
                     ? 1
                     : 0; // planning_result.point_num > 50 ||
  if (error_status) {
    is_planning_result_set_ = false;
    ROS_ERROR_THROTTLE(1, "~ point_num is wrong : %d ",
                       planning_result.point_num);
    return;
  }

  if (last_pathtype != planning_result.pathtype) {
    ROS_INFO_THROTTLE(2, "New path detected");
    need_turn_for_new_path = true;
    align_to_path_point = true; // ��·��������������Ҫ���򿿽�·�����??
  }

  if (need_turn_for_new_path) {
    if (align_to_path_point && planning_result.pathtype == 0) {
      double dx = planning_result.x[0] - car_position.position_x;
      double dy = planning_result.y[0] - car_position.position_y;
      double distance_to_start = hypot(dx, dy);
      double desired_heading = atan2(dy, dx);
      double heading_error =
          robot::geometry::NormalizeAngle(desired_heading - car_position.yaw);
      ROS_INFO("Align to path point: distance = %.2f, heading_error = %.3f",
               distance_to_start, heading_error);
      if (distance_to_start > 0.05) {
        if (fabsf(heading_error) > 0.08 && !already_moving_straight) {
          command.drive_value = 0;//1500
          command.turn_value = (heading_error > 0) ? - 48: 48;//1270 : 1730
          distance_increase_count = 0;
          ROS_INFO("Adjusting heading to target point...");
        } else {
          already_moving_straight = true;
          if (distance_to_start > last_distance_to_start) {
            distance_increase_count++;
          } else {
            distance_increase_count = 0; // �б�С������
          }

          if (distance_increase_count >= 3) {
            align_to_path_point = false;
            distance_increase_count = 0;
          }
          command.drive_value = 25;//1600
          command.turn_value = 0;//1500
          last_distance_to_start = distance_to_start;
        }
      } else {
        // �������??
        align_to_path_point = false;
        distance_increase_count = 0;
        ROS_INFO("Alignment completed.");
      }
    }
    // === ԭ�нǶ������߼� ===
    double heading = robot::geometry::NormalizeAngle(
        planning_result.heading[0] - car_position.yaw);
    if (fabsf(heading) <= 0.06) {
      geometry_msgs::Point point_msg;
      point_msg.z = 999;
      path_too_far_pub_.publish(point_msg);
      ROS_WARN("first gear =2 dropped");
      need_turn_for_new_path = false;
      ResetFlag(); //
                   // command.drive_value = 1730; // 1750
    } else {
      command.drive_value = 0;//1500
      command.turn_value = (heading > 0) ? -48 : 48;//1270 : 1730
    }
  }

  last_pathtype = planning_result.pathtype;
  is_planning_result_set_ = true;
}

/////////////////////////////////////////////////////////////////////
void PurePursuit::callbackFromSpeedInfo(
    const util::LocalPoseConstPtr &msg_speed_info) {
  vehicle_info = *msg_speed_info;
  int v_speed = vehicle_info.vehicle_speed; // int32 cm/s
  is_velocity_set_ = true;
}

void PurePursuit::callbackFromPos(
    const util::PositionConstPtr &msg_carposition) {
  car_position = *msg_carposition;
  is_carposition_set_ = true;
}

void PurePursuit::callbackFromDirectControl(
    const mower_msgs::Direct_ControlConstPtr &msg_direct_control) {
  direct_control = *msg_direct_control;
  ROS_INFO("direct_control");
}

/* task-stop */
void PurePursuit::callbackFromTaskstop(const std_msgs::Bool &task_msg) {
  stop_car_flag = task_msg.data;
}
/* Avoidstate */
void PurePursuit::callbackFromAvoidstate(const std_msgs::UInt8 &avoid_msg) {
  avoid_state_data = avoid_msg.data;
}
void PurePursuit::callbackFromSignal(const std_msgs::StringConstPtr &string) {

  std::cout<<"string->data:"<<string->data<<std::endl;
  if (string->data == "high") {
    mower_height_cfg = 0;
    ROS_INFO("mower_height = 0");
  }
  else if (string->data == "medium") {
    mower_height_cfg = 1;
    ROS_INFO("mower_height = 1");
  }
  else if (string->data == "low") {
    mower_height_cfg = 2;
    ROS_INFO("mower_height = 2");
  }
  else if (string->data == "open") {
    mover_bool_cfg = 1;
    ROS_INFO("mover_bool_cfg = 1");
  }
  else if (string->data == "close") {
    mover_bool_cfg = 0;
    ROS_INFO("mover_bool_cfg = 0");
  }
}

void PurePursuit::command_publish() {
  mower_msgs::VehicleCmd cmd_msg;
  cmd_msg.turn_value = command.turn_value;
  cmd_msg.drive_value = command.drive_value;
  cmd_msg.ad_control_enable = 1;

  if (planning_result.gear[SPEED_TARGET_POINT] != 0) {
    cmd_msg.mover_bool = mover_bool_cfg;     // ��?�yaml ����
    cmd_msg.mower_height = mower_height_cfg; //
    if (planning_result.gear[SPEED_TARGET_POINT] == 1) {
      if (planning_result.speed[SPEED_TARGET_POINT] != 0) {
        cmd_msg.gear_model = cmd_msg.D_Gear; // D: 3(1)  N: 2(2)  p: 0
      } else {
        cmd_msg.gear_model = cmd_msg.p_Gear; // gear=1,but speed=0;
        cmd_msg.mover_bool = mover_bool_cfg;
      }
    } else if (planning_result.gear[SPEED_TARGET_POINT] == 2) {
      cmd_msg.gear_model = cmd_msg.N_Gear;
    } else {
      cmd_msg.gear_model = cmd_msg.R_Gear;
    }
  } else {
    cmd_msg.gear_model = cmd_msg.p_Gear;
    cmd_msg.mover_bool = mover_bool_cfg;
    cmd_msg.turn_value = 0;//1500
    cmd_msg.drive_value = 0;//1500
  }
  // @�滮���һ�������⣺�����߼�����֤�?��?
  if (cmd_msg.gear_model == 0) {
    cmd_msg.mover_bool = mover_bool_cfg;
    cmd_msg.turn_value = 0;//1500
    cmd_msg.drive_value = 0;//1500
    cmd_msg.ad_control_enable = 0;
    ROS_INFO("$$bb stop ~~ gear =0");
  }

  // add flag to car_stop_status
  // if (stop_car_flag || c_finish ||stop_tem_flag || stop_path_flag)
  if (stop_car_flag || c_finish || (stop_tem_flag && !need_turn_for_new_path) ||
      stop_path_flag) // cnk 0512
  {
    mower_msgs::VehicleCmd quit_cmd;
    quit_cmd.ad_control_enable = 1; // Ҫ��Ҫ��
    quit_cmd.mower_height = cmd_msg.mower_height;
    quit_cmd.gear_model = cmd_msg.gear_model;
    quit_cmd.mover_bool = cmd_msg.mover_bool;
    last_turn_value = (last_turn_value < 30 && last_turn_value > -30)
                          ? last_turn_value
                          : 0;
    quit_cmd.turn_value = last_turn_value;
    quit_cmd.drive_value = 0;
    if (c_finish) {
      quit_cmd.ad_control_enable = 0;
      quit_cmd.gear_model = cmd_msg.p_Gear;
      quit_cmd.mover_bool = mover_bool_cfg;
      ROS_INFO("ALL~~~~~~~~~Finished");
    }

    // ROS_INFO("stop car~~~~~,stop_tem %d,stop_car_flag %d,stop_path %d",
    // stop_tem_flag, stop_car_flag, stop_path_flag); ROS_INFO("D10$stop pub $
    // t_v %d,d_v %d,gear %d,ad %d", quit_cmd.turn_value,
    // quit_cmd.drive_value,quit_cmd.gear_model,quit_cmd.ad_control_enable);
    quit_cmd.header.stamp = ros::Time::now(); // ����ʱ���??
    pub_Command.publish(quit_cmd);
    // ����ͣ��
    static int stop_num = 0;
    stop_num++;

    if (stop_num > 10 && stop_path_flag) // TODO @cnk
    {
      stop_num = stop_num > 15 ? 0 : stop_num;
      if (!planning_result.x.empty()) {
        geometry_msgs::Point point_msg;
        point_msg.x = planning_result.x[0];
        point_msg.y = planning_result.y[0];
        path_too_far_pub_.publish(point_msg);
        // ROS_INFO("Published path_too_far_point: x = %.2f, y = %.2f",
        // point_msg.x, point_msg.y);
      } else {
        ROS_WARN(
            "Planning result is empty. Cannot publish path_too_far_point.");
      }
    }
  } else {
    last_turn_value = cmd_msg.turn_value;    //: 1225 add
    cmd_msg.header.stamp = ros::Time::now(); // ����ʱ���??
    
    // ���ӵ�����־���ر��ע״̬�л�ʱ�Ŀ�������??
    static int last_avoid_state = -1;
    if (avoid_state_data != last_avoid_state) {
      ROS_INFO("State changed: %d -> %d, cmd: turn=%d, drive=%d, gear=%d", 
               last_avoid_state, avoid_state_data, 
               cmd_msg.turn_value, cmd_msg.drive_value, cmd_msg.gear_model);
      last_avoid_state = avoid_state_data;
    }
    
    pub_Command.publish(cmd_msg);
    // ROS_INFO("mower_height = %d",cmd_msg.mower_height);
     ROS_INFO("D10$cmd pub $ t_v %d,d_v %d,gear %d,ad %d", cmd_msg.turn_value,
     cmd_msg.drive_value, cmd_msg.gear_model,cmd_msg.ad_control_enable);
    // //@Debug10
  }
}

void PurePursuit::controlError_publish() {
  mower_msgs::ControlError ctlE_msg;
  ctlE_msg.header.stamp = ros::Time::now(); // ����ʱ���??
  ctlE_msg.e_pos = ctlE.e_pos;
  ctlE_msg.e_theta = ctlE.e_theta;
  // float du = ctlE.e_theta; //���� degree
  ctlE_msg.e_lat = 44.4; // ��δ��ֵ
  // ROS_INFO("CE$ pub $ e_pos %.4f,e_theta_deg %.4f", ctlE_msg.e_pos,
  // ctlE_msg.e_theta);
  pub_CtlError.publish(ctlE_msg);
}

void PurePursuit::initForROS() {
  // ros parameter settings

  // sub_topics_params
  nh_.param("sub_planning_result_topic", sub_planning_result_topic,
            std::string("/lawn_mower/global_path")); // �ֲ��滮
  nh_.param("sub_speed_info_topic", sub_speed_info_topic,
            std::string("/nanobot/localpose")); // ���ö�λ�ķ���
  nh_.param("sub_pos_topic", sub_pos_topic,
            std::string("/Mower/position")); // ��λ��Ϣ
  nh_.param("sub_direct_control_topic", sub_direct_control_topic,
            std::string("/mower/direct_control")); // APP����
  nh_.param("sub_stop_car_topic", sub_stop_car_topic,
            std::string("/mower/stop_car")); // �Ӿ�ͣ��
  nh_.param("sub_avoidstate_topic", sub_avoidstate_topic,
            std::string("/lawn_mower/avoid_state")); // ��̬����

  // setup subscriber
  sub1_ = nh_.subscribe(sub_planning_result_topic, 1,
                        &PurePursuit::callbackFromPlanningResult, this);
  sub2_ = nh_.subscribe(sub_speed_info_topic, 1,
                        &PurePursuit::callbackFromSpeedInfo, this);
  sub4_ = nh_.subscribe(sub_pos_topic, 5, &PurePursuit::callbackFromPos, this);
  sub5_ = nh_.subscribe(sub_direct_control_topic, 1,
                        &PurePursuit::callbackFromDirectControl, this);
  substop = nh_.subscribe(sub_stop_car_topic, 1,
                          &PurePursuit::callbackFromTaskstop, this);
  sub_avoid = nh_.subscribe(sub_avoidstate_topic, 1,
                            &PurePursuit::callbackFromAvoidstate, this);
  sub_signal_ = nh_.subscribe("/signal", 1, 
                            &PurePursuit::callbackFromSignal, this);

  // setup publisher
  pub_Command = nh_.advertise<mower_msgs::VehicleCmd>("/vehicle/cmd", 1);
  pub_Controlok = nh_.advertise<mower_msgs::ControlOk>("/mower/control_ok", 1);
  pub_CtlError =
      nh_.advertise<mower_msgs::ControlError>("/mower/control_error", 1);
  path_too_far_pub_ =
      nh_.advertise<geometry_msgs::Point>("/path_too_far_point", 1); //@cnk
}

//
int reset_cnt = 0;
int reset_pos_cnt = 0;
void PurePursuit::run() {
  ROS_INFO_STREAM("control node is ready!");
  ROS_INFO_STREAM("hl_control version: " << getVersion());
  // ���� YAML �����ļ�
  try {
    YAML::Node config = YAML::LoadFile("/home/nvidia/crawler_control/src/"
                                       "pure_pursuit/chassis.yaml"); // ע��·��
    chassis_type = config["chassis_type"].as<int>();
    wheel_track = config["control_params"]["wheel_track"].as<float>();
    // wheel_base = config["control_params"]["wheel_base"].as<float>();
    mover_bool_cfg = config["control_params"]["mover_bool"].as<int>();
    mower_height_cfg = config["control_params"]["mower_height"].as<int>();
    std::cout << "Chassis Type: " << chassis_type << std::endl;
    std::cout << "Wheel Track: " << wheel_track << std::endl;
    std::cout << "Basic Config ## m_bool: " << mover_bool_cfg
              << ", --m_height: " << mower_height_cfg << std::endl;
    // std::cout << "Wheel Base: " << wheel_base << std::endl;
  } catch (const YAML::BadFile &e) {
    std::cerr << "Error: " << e.what() << std::endl;
    return;
  }

  mower_msgs::ControlOk Control_Ok_msg;
  ros::Rate loop_rate(LOOP_RATE_); // init: 50

  // ����״̬�л����ɱ���
  static bool was_reversing = false;
  static bool first_stop = false;
  static ros::Time reverse_stop_time;
  
  while (ros::ok()) {
    ros::spinOnce();

    if(avoid_state_data==4){
      reset_pos_cnt++;
      if (reset_pos_cnt == 20) {
        reset_pos_cnt = 0;
        is_carposition_set_ = false;
      }
    }

    Control_Ok_msg.is_control_ok = true;
    std::cout<<"is_carposition_set_ = "<<is_carposition_set_<<std::endl;
    if(!is_carposition_set_ || stop_car_flag)
    {
        mower_msgs::VehicleCmd stop_cmd;
        stop_cmd.turn_value = 0;//1500
        stop_cmd.drive_value = 0; //1500 ͣ��
        stop_cmd.ad_control_enable = 1;
        stop_cmd.gear_model = 1;
        stop_cmd.mover_bool = mover_bool_cfg;
        stop_cmd.mower_height = mower_height_cfg;
        stop_cmd.header.stamp = ros::Time::now();
        pub_Command.publish(stop_cmd);
        ROS_INFO("NO position or stop_car");
        loop_rate.sleep();
        continue;
    }
    // ���ӵ���״̬�л�����
    if (was_reversing && !first_stop && avoid_state_data != 4) {
      reverse_stop_time = ros::Time::now();
      first_stop = true;
      ROS_INFO("Transitioning from reverse to forward...");
    }
    
    if(avoid_state_data==4 && !stop_car_flag)
    {
      ROS_INFO("avoid_state_data==4~~~~~~~~~~~~~~~~~~~~");
      mower_msgs::VehicleCmd cmd_msg;
      cmd_msg.turn_value = 0;//1500
      cmd_msg.drive_value = -15;//1300
      cmd_msg.ad_control_enable = 1;
      cmd_msg.gear_model = 1; // gear=1,but speed=0;
      cmd_msg.mover_bool = mover_bool_cfg;
      cmd_msg.mower_height = mower_height_cfg;
      cmd_msg.header.stamp = ros::Time::now(); // ����ʱ���??
      pub_Command.publish(cmd_msg);
      was_reversing = true;
      loop_rate.sleep();
      continue;
    }
    
    // ״̬�л���Ĺ��ɴ���??
    if (was_reversing && avoid_state_data != 4) {
      double transition_time = (ros::Time::now() - reverse_stop_time).toSec();
      
      // �ȷ���ͣ�����?������ͣ�??
      if (transition_time < 5) { // ���ӵ�0.3�룬?�����ȫ�?ֹ
        mower_msgs::VehicleCmd stop_cmd;
        stop_cmd.turn_value = 0;//1500
        stop_cmd.drive_value = 0; // 1500ͣ��
        stop_cmd.ad_control_enable = 1;
        stop_cmd.gear_model = 1;
        stop_cmd.mover_bool = mover_bool_cfg;
        stop_cmd.mower_height = mower_height_cfg;
        stop_cmd.header.stamp = ros::Time::now();
        pub_Command.publish(stop_cmd);
        ROS_INFO("Stopping after reverse, transition_time: %.3f, avoid_state: %d", 
                 transition_time, avoid_state_data);
        loop_rate.sleep();
        continue;
      } else {
        // ������ɣ��ָ���������??
        was_reversing = false;
        first_stop = false;
        ROS_INFO("Reverse transition completed, resuming normal control, avoid_state: %d", 
                 avoid_state_data);
      }
    }

    /*** �źŴ������������� ***/
    // if (is_planning_result_set_ && is_velocity_set_ && is_carposition_set_)
    // //��ʻģʽ��ʱ�޸�
    if (is_planning_result_set_ && is_carposition_set_ && !was_reversing) // ��ʻģʽ��ʱ�޸�?����ӹ���״̬���?

    {
      // path_follow algorithm
      latcontrol_algorithm();

      command_publish();
      controlError_publish();

      //
      reset_cnt++;
      if (reset_cnt == 10) {
        reset_cnt = 0;
        is_carposition_set_ = false;
      }
    } else {
      // ����ڹ����ڼ䣬�����?������?
      if (was_reversing) {
        mower_msgs::VehicleCmd stop_cmd;
        stop_cmd.turn_value = 0;//1500
        stop_cmd.drive_value = 0;//1500
        stop_cmd.ad_control_enable = 1;
        stop_cmd.gear_model = 1;
        stop_cmd.mover_bool = mover_bool_cfg;
        stop_cmd.mower_height = mower_height_cfg;
        stop_cmd.header.stamp = ros::Time::now();
        pub_Command.publish(stop_cmd);
        ROS_INFO("Transition period - sending stop command");
      }
      
      static int scount = 0;
      scount++;
      if (scount > 3 * LOOP_RATE_) {
        if (!is_planning_result_set_) {
          ROS_INFO(" $$ no planning");
        }

        scount = 0;
      }
    }

    /****** ������ ******/
    static int tnum = 0;
    tnum++;
    if (tnum > 3 * LOOP_RATE_) {
      auto now = ros::Time::now();
      // ROS_INFO("[ %s, ]~$$  MAP is  :  %d ,$$ v_info is :
      // %d",timestampToDate(now).c_str(),is_carposition_set_ ,is_velocity_set_
      // );
      tnum = 0;
    }

    // is_planning_result_set_ = false;
    // is_carposition_set_ = false;
    // is_velocity_set_ = false;
    pub_Controlok.publish(Control_Ok_msg);
    loop_rate.sleep();
  }
}

// �������?? current_speed ��ָ�����??�滮ֵ
// desire_speed ����desire_speedû������?��һᱨ�δ���?
int calculateDriveValue(float current_speed, float desire_speed, bool flag,
                        uint8_t avoid_state_data) {
  static int th_dv = 0;//1500
  // int th_v = (int)(4.0989*current_speed + 1660); //ϵ��kv
  //��add 0405
  if (avoid_state_data == 3) {
    th_dv = 0;//1500
  } else if (avoid_state_data == 2) {
    th_dv =30; // 1730
  } else {
    if (current_speed <= 25) {
      th_dv = 20; // ���� 1730
    } else if (current_speed < 35) {
      th_dv = 30; // 1800
    } else {
      th_dv = 40; // 1900
    }
  }
  // int cd_value = flag ? 1500 : th_dv;
  // if (avoid_state_data >= 1)
  // {
  //     ROS_INFO("CD_value @ d_v %d,avoid_state.data %d,turn_flag %d",
  //     cd_value, avoid_state_data, flag);
  // }

  if (flag) {
    return 0;//1500
  } else {
    return th_dv;
  }
}

// �Ǳ궨�� �������??
int calculateTurnValue(bool latest_gear_flag, waypose local_waypose,
                       waypose *c_goal, unsigned char cgoal_id, int last_tv) {
  // 1���ж���һת��ֵ�� ��ֱ ���� ��������
  static bool dev_flag = 0; // ���е���
  static bool sl_flag = 0;  // ��ֱ
  static bool cu_flag = 0;  // ����
  static int t_value = ctv;
  static float h = 0;
  int det_tv = 0;
  if (abs(last_tv - 0) < 1) {//0��1500��0.025��10
    sl_flag = 1;
    cu_flag = 0;
  } else {
    sl_flag = 0;
    cu_flag = 1;
  }
  int x_sign = local_waypose.point.x > 0 ? 1 : -1; // 1 �������??
  int h_sign = local_waypose.heading > 0 ? 1 : -1; // 1 ������??
  float h_value = latest_gear_flag == 0
                      ? local_waypose.heading
                      : 0; // �Ż�ת���ǰ��??heading ����  25-04-22
  // 0.01 rad ~ 0.573 deg
  if (fabs(c_goal->heading - h) > 0.015 ||
      fabs(c_goal->point.x - local_waypose.point.x) * 100 > 12) {
    dev_flag = 1;
    h = c_goal->heading;
  } else { // 250312 add
    dev_flag = 0;
  }
  // ROS_INFO("CT01#dev_flag %d,goal->heading %.3f, CT1# %.3f, CT2#
  // %.2f",dev_flag,c_goal->heading*180/M_PI
  //         ,(c_goal->heading - h)*180/M_PI, (c_goal->point.x -
  //         local_waypose.point.x)*100);

  // ������������?���? (��������ʱ)
  if (fabs(local_waypose.point.x) < 0.10 &&
      fabs(-local_waypose.heading) > 0.05 && cu_flag) {
    int tmp_value = 0;
    // h_sign ����������Ҵ�??
    if (h_sign == 1) {
      if (x_sign == 1) {
        det_tv = 5; // Сֵ
        tmp_value =last_tv + det_tv;
      } else {
        det_tv = -10;
        tmp_value =last_tv + det_tv;
      }
      // tmp_value = last_tv+det_tv < 1420? ctv-10 : last_tv+det_tv; //ԭ
      // tmp_value = last_tv + det_tv < -20 ? last_tv - det_tv
      //                                     : last_tv + det_tv; // 250312 ��amend
    } else {
      if (x_sign == 1) {
        det_tv = 10;
        tmp_value =last_tv + det_tv;
      } else {
        det_tv = -5; // Сֵ
        tmp_value =last_tv + det_tv;
      }
      // tmp_value = last_tv+det_tv > 1580? ctv+10 : last_tv+det_tv;
      // tmp_value = last_tv + det_tv > 20 ? last_tv - det_tv
      //                                     : last_tv + det_tv; // 250312 ��amend
    }
    t_value = tmp_value;
    // ROS_INFO("CT99#last_tv %d,t_value = %d, det_tv = %d", last_tv,t_value,
    // det_tv);
    return t_value;
  }

  // �����ж�?��������ĵ�?  �����??0.045
  if (dev_flag && c_goal->point.y > 0.5) {
    if (fabs(local_waypose.point.x) <= 0.05 &&
        fabs(-local_waypose.heading) <= 0.04) {
      t_value = sl_flag ? last_tv : ctv;
    } else if (fabs(local_waypose.point.x) > 0.05 ||
               fabs(-local_waypose.heading) > 0.04) {
      if (sl_flag) {
        det_tv = (local_waypose.point.x - (h_value));
      } else {
        det_tv =
            static_cast<int>(2 * (local_waypose.point.x -
                                  (h_value))); // ������򣬼�С�����
        int sign = det_tv > 0 ? 1 : -1;              // ����
        det_tv = abs(det_tv) < 2.5 ? det_tv : sign * 2.5; // ���������಻����
      }
      t_value = last_tv == 0 ? ctv : ctv + det_tv;
    }
    // dev_flag = 0;
  }

  // add ��С��������߼�??
  if (fabs(local_waypose.point.x) >= 0.10 && abs(last_tv - 0) < 1) {//1500
    det_tv =(1.3 * local_waypose.point.x - (h_value));
    t_value = last_tv == 0 ? ctv : ctv + det_tv;
    // ROS_INFO("CT10#last_tv %d,t_value = %d,det_tv = %d,cgoal_id = %d",
    // last_tv,t_value,det_tv,cgoal_id);
    return t_value;
  }
  // ROS_INFO("CT9#last_tv %d,t_value = %d,det_tv = %d,cgoal_id = %d",
  // last_tv,t_value,det_tv,cgoal_id);
  return t_value;
}

// transtime()
std::string timestampToDate(const ros::Time &time) {
  time_t seconds = time.sec + 8 * 60 * 60; // hoursOffset 8
  struct tm *timeinfo = gmtime(&seconds);  // ʹ��gmtime��?�UTCʱ��

  std::stringstream ss;
  ss << std::put_time(timeinfo, "%Y-%m-%d %H:%M:%S"); // ��ʽ�����������ʱ����??
  return ss.str();
}

// version
std::string getVersion() {
  std::stringstream strs;
  std::string ss;
  /*
      250305�𣬸��ٵ����������log��3��12��?�������?27�� ?����궨��?;0411
     ��λ����ͳһ; 0430 avoid_data = 1����
  */
  strs << VERSION << "_2025/05/06_1400";
  ss = strs.str();
  return ss;
}
/* ��Ԫ���κ�����yq = a * xq^2 + b * xq + c
int quadraticFunction(double a, double b, double c, double x){
    double y = a * x * x + b * x + c;
    return static_cast<int>(y);
}*/

double getDelay(const ros::Time &now, const ros::Time &last) {
  return fabs(last.toSec() - now.toSec());
}
